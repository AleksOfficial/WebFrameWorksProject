import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../_helpers/must-match.validator';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  registerForm: FormGroup = this.formBuilder.group({
      email: ['', [Validators.email, Validators.required]],
      password: ['', Validators.required],
      passwordConfirm: ['', Validators.required],
      postalCode: ['', Validators.pattern("[0-9]+")]
    }, {
      validator: MustMatch("password", "passwordConfirm")
    }
  );
  hide = true;
  isLoading = false;
  noMatch = false;

  getPasswordErrorMessage() {
    return this.registerForm.get("password")!.hasError('required') ? 'You must enter a password' : '';
  }

  getPasswordConfirmErrorMessage() {
    if (this.registerForm.get("passwordConfirm")!.hasError('mustMatch')) {
      return "Passwords must match";
    }
    return this.registerForm.get("passwordConfirm")!.hasError('required') ? 'You must confirm your password' : '';
  }

  getEmailErrorMessage() {
    if (this.registerForm.get("email")!.hasError('required')) {
      return 'You must enter a valid email adress';
    }

    return this.registerForm.get("email")!.hasError('email') ? 'Not a valid email address' : '';
  }

  getPostalCodeErrorMessage() {
    return this.registerForm.get("postalCode")!.hasError("pattern") ? "Enter valid postal code (numbers only)" : "";
  }

  onSubmit() {
  }

  constructor(private formBuilder: FormBuilder) { 
   }

  ngOnInit(): void {
  }

}
