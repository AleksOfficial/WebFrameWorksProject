import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, NgForm} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', Validators.required);
  hide = true;
  isLoading = false;

  getPasswordErrorMessage() {
    return this.password.hasError('required') ? 'You must enter a password' : '';
  }

  getEmailErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a valid email adress';
    }

    return this.email.hasError('email') ? 'Not a valid email address' : '';
  }

  onSubmit() {
    if (this.getPasswordErrorMessage() != '' || this.getEmailErrorMessage() != '') {
      return;
    }
    if (this.email.value == "test@test.at" && this.password.value == "12345678") {
      console.log("Login successful!");
    } else {
      console.log("Login unsuccessful!");
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
